<?php
namespace Magentostudy\News\Api;
 
 
interface getNewsInterface {


	/**
	 * GET for Post api
	 * @return string
	 */
	
	public function getNews();
}