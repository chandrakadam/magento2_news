<?php
namespace Magentostudy\News\Controller;

use Magento\Framework\App\ActionInterface;

interface NewsInterface extends ActionInterface
{
}
