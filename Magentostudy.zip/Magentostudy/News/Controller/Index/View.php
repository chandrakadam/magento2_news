<?php
namespace Magentostudy\News\Controller\Index;

use Magentostudy\News\Controller\NewsInterface;

class View extends \Magentostudy\News\Controller\AbstractController\View implements NewsInterface
{

}
