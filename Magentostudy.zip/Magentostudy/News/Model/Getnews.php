<?php 
namespace Magentostudy\News\Model; 
class Getnews {

    protected $resourceConnection;
    
    public function __construct(            
            \Magento\Framework\App\ResourceConnection $resourceConnection, 
            \Magento\Framework\Webapi\Rest\Request $request
    ) { 
        $this->resourceConnection = $resourceConnection; 
        $this->_request = $request;
    }
    
    public function getNews()
    {
        $newsId = (int)$this->_request->getParam('news_id'); 
        $query = "SELECT * from magentostudy_news where news_id = ".$newsId;
        $results = $this->resourceConnection->getConnection()->fetchAll($query);
        
        if(count($results) > 0)
        {
            foreach($results as $result)
            { 
                $return['results'][] = [
                    'title' => $result['title'],
                    'content' => $result['content'],
                    'image' => $result['image']
                ]; 
            }

            $return['status'] = 'success';
            $return['message'] = '';

        } else {
            
            $return = [
                'results' => [], 
                'status'=>'success', 
                'message' =>'no record found'
            ];
        }
         
        echo json_encode($return, JSON_PRETTY_PRINT);
        exit;
    }
}