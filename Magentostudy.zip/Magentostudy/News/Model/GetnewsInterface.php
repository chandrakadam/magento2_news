<?php
namespace Magentostudy\News\Model;
 
 
class Getnews{

	/**
	 * {@inheritdoc}
	 */
	public function getNews()
	{
		return 'api GET return the $param ';
	}
}