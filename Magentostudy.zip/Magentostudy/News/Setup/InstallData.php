<?php

namespace Magentostudy\News\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{

	/**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {

// Set up data rows
$dataRows = [
    [
        'title'          => 'Magento test 1', 
        'content'        => '<p>  test 1</p>',
    ],
    [
        'title'          => 'Magento test 2',
        'content'        => '<p>test</p>'
    ],
];

		// Generate news items
		foreach ($dataRows as $data) {
			//$this->createNews()->setData($data)->save();
			$setup->getConnection()->insert($setup->getTable('magentostudy_news'), $data);
		}
	}
}